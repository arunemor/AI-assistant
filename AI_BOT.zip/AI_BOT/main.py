import sys
import pyperclip
import requests
from PyQt5.QtWidgets import (
    QApplication, QWidget, QTextEdit, QComboBox,
    QVBoxLayout, QPushButton, QHBoxLayout, QMenu,
    QCheckBox, QLineEdit
)
from PyQt5.QtCore import Qt, QTimer, QPoint
from PyQt5.QtGui import QFont, QPainter, QColor, QPen, QRegion
from deep_translator import GoogleTranslator

# -------------------- Floating Draggable Circular Icon --------------------
class MiniIcon(QWidget):
    def __init__(self, translator_popup):
        super().__init__()
        self.translator_popup = translator_popup
        self.setWindowFlags(Qt.WindowStaysOnTopHint | Qt.FramelessWindowHint | Qt.Tool)
        self.setGeometry(1300, 700, 50, 50)
        self.setStyleSheet("background: transparent;")
        self.old_pos = None
        self.setMask(QRegion(0, 0, 50, 50, QRegion.Ellipse))
        self.show()
        self.setContextMenuPolicy(Qt.CustomContextMenu)
        self.customContextMenuRequested.connect(self.show_context_menu)

    def show_context_menu(self, pos):
        menu = QMenu()
        exit_action = menu.addAction("Exit Bot")
        action = menu.exec_(self.mapToGlobal(pos))
        if action == exit_action:
            QApplication.quit()

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            icon_geo = self.geometry()
            self.translator_popup.move(icon_geo.x() - 250, icon_geo.y() - 50)
            self.translator_popup.show()
            self.old_pos = event.globalPos()
        elif event.button() == Qt.RightButton:
            self.show_context_menu(event.pos())

    def mouseMoveEvent(self, event):
        if self.old_pos:
            delta = QPoint(event.globalPos() - self.old_pos)
            self.move(self.x() + delta.x(), self.y() + delta.y())
            self.old_pos = event.globalPos()

    def mouseReleaseEvent(self, event):
        self.old_pos = None

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        painter.setBrush(QColor(0, 0, 0))
        painter.setPen(QPen(Qt.black))
        painter.drawEllipse(0, 0, 50, 50)
        painter.setPen(QPen(Qt.white))
        font = QFont("Arial", 20, QFont.Bold)
        painter.setFont(font)
        painter.drawText(self.rect(), Qt.AlignCenter, "A")


# -------------------- Translator + Ollama Chat Popup --------------------
class MiniTranslator(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowFlags(Qt.WindowStaysOnTopHint | Qt.FramelessWindowHint)
        self.setGeometry(1100, 400, 360, 350)
        self.setStyleSheet("""
            background-color: #1e1e2f;
            border-radius: 12px;
            border: 2px solid #6a11cb;
        """)
        self.old_pos = None

        # -------- Buttons --------
        self.close_btn = QPushButton("✕")
        self.close_btn.setFixedSize(25, 25)
        self.close_btn.setStyleSheet("color:white; background: #ff4c4c; border:none;")
        self.close_btn.clicked.connect(self.hide)

        self.minimize_btn = QPushButton("—")
        self.minimize_btn.setFixedSize(25, 25)
        self.minimize_btn.setStyleSheet("color:white; background: #4c6aff; border:none;")
        self.minimize_btn.clicked.connect(self.showMinimized)

        self.clear_btn = QPushButton("Clear")
        self.clear_btn.setFixedSize(50, 25)
        self.clear_btn.setStyleSheet("color:white; background: #00c853; border:none;")
        self.clear_btn.clicked.connect(lambda: self.text_area.clear())

        self.refresh_btn = QPushButton("↻")
        self.refresh_btn.setFixedSize(30, 25)
        self.refresh_btn.setStyleSheet("color:white; background:#ffaa00; border:none;")
        self.refresh_btn.clicked.connect(self.translate_last_text)

        btn_layout = QHBoxLayout()
        btn_layout.addWidget(self.clear_btn)
        btn_layout.addWidget(self.refresh_btn)
        btn_layout.addStretch()
        btn_layout.addWidget(self.minimize_btn)
        btn_layout.addWidget(self.close_btn)
        btn_layout.setContentsMargins(5, 5, 5, 5)

        # -------- Language Selection --------
        self.language_box = QComboBox()
        self.language_box.addItems(["hindi", "english", "spanish", "french", "german", "chinese", "arabic"])
        self.language_box.setStyleSheet("background-color: #6a11cb; color:white; border-radius:5px; padding:2px;")
        self.language_box.currentIndexChanged.connect(self.translate_last_text)

        # -------- Ollama Toggle --------
        self.ollama_checkbox = QCheckBox("Use Ollama")
        self.ollama_checkbox.setStyleSheet("color:white;")
        self.ollama_checkbox.stateChanged.connect(self.toggle_ollama_mode)

        # -------- Text Display Area --------
        self.text_area = QTextEdit()
        self.text_area.setReadOnly(True)
        self.text_area.setStyleSheet("background-color:#2b2b3f; color:white; border-radius:5px;")

        # -------- Input Box for Ollama --------
        self.input_box = QLineEdit()
        self.input_box.setPlaceholderText("Type your question about selected text...")
        self.input_box.setStyleSheet("background:#3a3a4f; color:white; border-radius:5px; padding:5px;")
        self.input_box.returnPressed.connect(self.send_ollama_message)
        self.input_box.hide()

        # -------- Layout --------
        layout = QVBoxLayout()
        layout.addLayout(btn_layout)
        layout.addWidget(self.language_box)
        layout.addWidget(self.ollama_checkbox)
        layout.addWidget(self.text_area)
        layout.addWidget(self.input_box)
        layout.setContentsMargins(5, 5, 5, 5)
        self.setLayout(layout)

        # -------- Clipboard Monitoring --------
        self.last_text = ""
        self.timer = QTimer()
        self.timer.timeout.connect(self.check_clipboard)
        self.timer.start(600)

    # -------- Drag behavior --------
    def mouseMoveEvent(self, event):
        if self.old_pos:
            delta = QPoint(event.globalPos() - self.old_pos)
            self.move(self.x() + delta.x(), self.y() + delta.y())
            self.old_pos = event.globalPos()

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.old_pos = event.globalPos()

    def mouseReleaseEvent(self, event):
        self.old_pos = None

    # -------- Clipboard --------
    def check_clipboard(self):
        text = pyperclip.paste().strip()
        if text and text != self.last_text:
            self.last_text = text
            if not self.ollama_checkbox.isChecked():
                self.translate_text(text)

    def translate_last_text(self):
        if self.last_text and not self.ollama_checkbox.isChecked():
            self.translate_text(self.last_text)

    # -------- Ollama mode --------
    def toggle_ollama_mode(self):
        if self.ollama_checkbox.isChecked():
            self.input_box.show()
            self.text_area.append("💬 Ollama mode enabled: ask questions about selected text...")
        else:
            self.input_box.hide()
            self.text_area.append("📝 Translator mode enabled.")

    def send_ollama_message(self):
        msg = self.input_box.text().strip()
        if not msg:
            return

        target_lang = self.language_box.currentText()
        selected_text = self.last_text
        if not selected_text:
            self.text_area.append("⚠️ Please select text first!")
            return

        self.text_area.append(f"<b><span style='color:#00c853'>You:</span></b> {msg}")
        self.input_box.clear()

        system_prompt = (
            f"You are an AI assistant. ONLY use the following selected text to answer user's question. "
            f"Do not provide any external information. Always reply in {target_lang}.\n\n"
            f"Selected text:\n{selected_text}"
        )

        try:
            response = requests.post(
                "http://127.0.0.1:11434/api/chat",
                json={
                    "model": "llama3.2",
                    "messages": [
                        {"role": "system", "content": system_prompt},
                        {"role": "user", "content": msg}
                    ],
                    "stream": False
                },
            )
            if response.status_code == 200:
                data = response.json()
                assistant_reply = data.get("message", {}).get("content", "")
                self.text_area.append(f"<b><span style='color:#4fc3f7'>Ollama:</span></b> {assistant_reply}")
            else:
                self.text_area.append(f"⚠️ Ollama returned {response.status_code}")
        except Exception as e:
            self.text_area.append(f"⚠️ {e}")

    # -------- Translator --------
    def translate_text(self, text):
        target_lang = self.language_box.currentText()
        try:
            translated = GoogleTranslator(source="auto", target=target_lang).translate(text)
            self.text_area.setText(translated)
        except Exception as e:
            self.text_area.setText(f"⚠️ Translation Error: {e}")


# -------------------- Main --------------------
if __name__ == "__main__":
    app = QApplication(sys.argv)
    translator_popup = MiniTranslator()
    icon = MiniIcon(translator_popup)
    sys.exit(app.exec_())
